package Fatimah;

public class Customer {

    private String FullName;
    private String Phone;
    private String ID;
    private String Email;
    private int Age;

    private boolean Diabetes, Hypertension, Heart_Disease;
    private String other;

    private String Language;

    private String Branch;
    private String subscription;
    private int cost;

        private String payment;

    public Customer() {

    }

    public String getFullName() {
        return FullName;
    }

    public void setFullName(String FullName) {
        this.FullName = FullName;
    }

    public String getPhone() {
        return Phone;
    }

    public void setPhone(String Phone) {
        this.Phone = Phone;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public int getAge() {
        return Age;
    }

    public void setAge(int Age) {
        this.Age = Age;
    }

    public boolean isDiabetes() {
        return Diabetes;
    }

    public void setDiabetes(boolean Diabetes) {
        this.Diabetes = Diabetes;
    }

    public boolean isHypertension() {
        return Hypertension;
    }

    public void setHypertension(boolean Hypertension) {
        this.Hypertension = Hypertension;
    }

    public boolean isHeart_Disease() {
        return Heart_Disease;
    }

    public void setHeart_Disease(boolean Heart_Disease) {
        this.Heart_Disease = Heart_Disease;
    }

    public String getLanguage() {
        return Language;
    }

    public void setLanguage(String Language) {
        this.Language = Language;
    }

    public String getOther() {
        return other;
    }

    public void setOther(String other) {
        this.other = other;
    }

    public String getBranch() {
        return Branch;
    }

    public void setBranch(String Branch) {
        this.Branch = Branch;
    }

    public String getSubscription() {
        return subscription;
    }

    public void setSubscription(String subscription) {
        this.subscription = subscription;
    }

    public int getCost() {
        return cost;
    }

    public void setCost(int cost) {
        this.cost = cost;
    }

    public String getPayment() {
        return payment;
    }

    public void setPayment(String payment) {
        this.payment = payment;
    }
    
    

}
